function store() {
    var inputusername = document.getElementById('username');
    var inputpassword = document.getElementById('password');
    localStorage.setItem('username', inputusername.value);
    localStorage.setItem('password', inputpassword.value);
    alert("Please Login to your Account");
    return false;
}

var elstore = document.getElementById('submit');
elstore.addEventListener('click', store, false);

function check() {
    var userName = document.getElementById('uname');
    var userPw = document.getElementById('pwd');
    var storedName = userName.value;
    var storedPw = userPw.value;
    if ((storedName == localStorage.getItem('username')) && (storedPw == localStorage.getItem('password'))) {
        window.open("index.html")
    } else {
        alert("Invalid Login");
    }
    return false;
}
var elcheck = document.getElementById('sub');
elcheck.addEventListener('click', check, false);
