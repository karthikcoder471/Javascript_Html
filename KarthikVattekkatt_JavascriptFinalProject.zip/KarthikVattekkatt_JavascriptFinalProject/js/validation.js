function fun3() {
    var a = document.getElementById('Name').value;
    if (a == "") {
        alert("please enter your name");
        return false;
    } else {
        if (!a.match(/^[a-zA-Z][a-zA-Z .]+$/)) {
            alert("please enter a name");
            document.getElementById('Name').value = "";
            return false;
        }
    }

}

function fun5() {
    var a = document.getElementById('username').value;
    if (a == "") {
        alert("please enter your name");
        e.stopPropagation();
        return false;
    } else {
        if (!a.match(/^[a-zA-Z][a-zA-Z0-9 ]+$/)) {
            alert("please enter a name");
            document.getElementById('username').value = "";
        }
    }

}


function fun7() {
    var a = document.getElementById('myName').value;
    if (a == "") {
        alert("please enter your name");
    } else {
        if (!a.match(/^[a-zA-Z][a-zA-Z0-9 ]+$/)) {
            alert("please enter a name");
            document.getElementById('myName').value = "";
        }
    }

}


function validateEmail() {
    var emailText = document.getElementById('email').value;
    var pattern = /^[a-zA-Z0-9\-_]+(\.[a-zA-Z0-9\-_]+)*@[a-z0-9]+(\-[a-z0-9]+)*(\.[a-z0-9]+(\-[a-z0-9]+)*)*\.[a-z]{2,4}$/;
    if (pattern.test(emailText)) {
        return true;
    } else {
        alert('Bad email address: ' + emailText);
        return false;
    }
}

function v_Email() {
    var emailText = document.getElementById('email_id').value;
    var pattern = /^[a-zA-Z0-9\-_]+(\.[a-zA-Z0-9\-_]+)*@[a-z0-9]+(\-[a-z0-9]+)*(\.[a-z0-9]+(\-[a-z0-9]+)*)*\.[a-z]{2,4}$/;
    if (pattern.test(emailText)) {
        return true;
    } else {
        alert('Bad email address: ' + emailText);
        return false;
    }
}
